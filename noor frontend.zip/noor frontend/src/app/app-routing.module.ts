import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { PlaceListComponent } from './place-list/place-list.component';
import { PlaceResolver } from './place-resolver';
import { PlaceComponent } from './place/place.component';
import { UserComponent } from './user/user.component';


const routes: Routes = [
  {path:'header',component:HeaderComponent},
  {path:'',component:HomeComponent},
  {path:'user',component:UserComponent},
  {path:'place',component:PlaceComponent,resolve:{place:PlaceResolver}},
  {path:'place-list',component:PlaceListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
