import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Place } from './place.model';

@Injectable({
  providedIn: 'root'
})
export class PlaceService {

  constructor(private httpClient: HttpClient) { }

  api = "http://localhost:8070/place"

  public savePlace(place: Place): Observable<any> {
    // Set the response type to 'text' to handle non-JSON responses
    const options = { responseType: 'text' as 'json' };
    return this.httpClient.post(`${this.api}/addplace`, place, options);
  }


  public getPlaces(): Observable<Place[]> {
    return this.httpClient.get<Place[]>(`${this.api}/getallplaces`);
  }

  public deletePlace(placeName: string): Observable<string> {
    return this.httpClient.delete(`${this.api}/deletePlace/${placeName}`, { responseType: 'text' });
  }

  public getPlace(placeName: string) {
    return this.httpClient.get<Place>(`${this.api}/getplacebyname/${placeName}`);
  }

  public updatePlace(place: Place): Observable<string> {
    return this.httpClient.put(`${this.api}/updateplaces/${place.placeName}`, place, { responseType: 'text' });
  }



}
