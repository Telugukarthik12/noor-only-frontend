import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Place } from '../place.model';
import { PlaceService } from '../place.service';

@Component({
  selector: 'app-place-list',
  templateUrl: './place-list.component.html',
  styleUrls: ['./place-list.component.css']
})
export class PlaceListComponent implements OnInit{

  dataSource:Place[]=[];

  displayedColumns: string[] = ['placeId','placeName', 'images','address','area','description','distance','tags','edit','delete'];

  constructor(private placeService:PlaceService,
    private router:Router){
    this.getPlaceList();
  }
  ngOnInit(): void {
    
  }

  getPlaceList(): void {
    this.placeService.getPlaces().subscribe(
      {
        next: (res: Place[]) => {
          this.dataSource = res;
        },
        error: (err: HttpErrorResponse)=> {
          console.log(err);
        }
      }
    );
  }

  deletePlace(placeName: string): void {
    console.log(placeName);
    this.placeService.deletePlace(placeName).subscribe({
      next: (res) => {
        console.log(res);
        this.getPlaceList();
      },
      error: (err: HttpErrorResponse) => {
        console.log(err);
      }
    });
  }

  updatePlace(placeName: string): void {
    this.router.navigate(['/place',{placeName:placeName}]);
  }
  
}
