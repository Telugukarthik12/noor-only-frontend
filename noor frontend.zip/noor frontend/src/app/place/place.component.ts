import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Place } from '../place.model';
import { PlaceService } from '../place.service';

@Component({
  selector: 'app-place',
  templateUrl: './place.component.html',
  styleUrls: ['./place.component.css']
})
export class PlaceComponent implements OnInit {

  isCreatePlace:boolean=true;
  place:any;
  
  constructor(private placeService: PlaceService,
    private router: Router,
    private activatedRoute:ActivatedRoute) {

  }
  ngOnInit(): void {
    this.place=this.activatedRoute.snapshot.data['place'];
    console.log(this.place);

    if(this.place&&this.place.placeName>0){
      this.isCreatePlace=false;
    }else{
      this.isCreatePlace=true;
    }
  }

  clearForm(form: NgForm): void {
    const confirmation = confirm('Are you sure you want to clear the form?'); // You can customize this confirmation dialog
    if (confirmation) {
      form.resetForm();
      this.place = {
        placeId: 0,
        placeName: '',
        images: '',
        address: '',
        area: '',
        distance: 0,
        description: '',
        tags: ''
      };
    }
  }


  // savePlace(placeForm: NgForm): void {
  //   if (this.isCreatePlace) {
  //     // Create a new place
  //     this.placeService.savePlace(this.place).subscribe(
  //       {
  //         next: (res: any) => {
  //           console.log(res);
  //           placeForm.reset();
  //           this.router.navigate(["/place-list"]);
  //         },
  //         error: (err: HttpErrorResponse) => {
  //           console.log(err);
  //         }
  //       }
  //     );
  //   } else {
  //     // Update an existing place
  //     this.placeService.updatePlace(this.place).subscribe(
  //       {
  //         next: (res: any) => {
  //           this.router.navigate(["/place-list"]);
  //         },
  //         error: (err: HttpErrorResponse) => {
  //           console.log(err);
  //         }
  //       }
  //     );
  //   }
  // }
  // place.component.ts
savePlace(placeForm: NgForm): void {
  if (this.isCreatePlace) {
    // Create a new place
    this.placeService.savePlace(this.place).subscribe({
      next: (res: any) => {
        console.log("Place created successfully:", res);
        placeForm.reset();
        this.router.navigate(["/place-list"]);
      },
      error: (err: HttpErrorResponse) => {
        console.error("Error creating place:", err);
        // Optionally: Display an error message to the user
      },
    });
  } else {
    // Update an existing place
    this.placeService.updatePlace(this.place).subscribe({
      next: (res: any) => {
        console.log("Place updated successfully:", res);
        this.router.navigate(["/place-list"]);
      },
      error: (err: HttpErrorResponse) => {
        console.error("Error updating place:", err);
        // Optionally: Display an error message to the user
      },
    });
  }
}

  

}
