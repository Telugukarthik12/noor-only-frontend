import { ActivatedRouteSnapshot, ResolveFn, RouterStateSnapshot } from "@angular/router";
import { PlaceService } from "./place.service";
import { inject } from "@angular/core";
import { Observable, of } from "rxjs";
import { Place } from "./place.model";

export const PlaceResolver: ResolveFn<any> =
  (route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot,
    placeService: PlaceService = inject(PlaceService)): Observable<Place> => {

    const placeName = route.paramMap.get("placeName");

    if (placeName !== null && placeName !== undefined) {
      // make api call and get data for given place name
      return placeService.getPlace(placeName);
    } else {
      // create and return empty place details
      const place: Place = {
        placeId: 0,
        placeName: '',
        images: '',
        address: '',
        area: '',
        distance: 0,
        description: '',
        tags: ''
      };

      return of(place);
    }
  };